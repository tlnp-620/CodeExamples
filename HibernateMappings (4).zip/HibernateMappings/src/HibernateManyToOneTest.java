import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateManyToOneTest {

	public static void main(String[] args) {
	
		
		Configuration cfg = new Configuration().configure("Hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		
		Faculty f1=new Faculty();
		f1.setFacName("Ram");
		f1.setFacSal(50000);
		
		Faculty f2=new Faculty();
		f2.setFacName("Krish");
		f2.setFacSal(70000);
		
		
		
		College c=new College();
		c.setCollegeName("SVH College");
		c.setCollegeAddress("MTM");
		c.setFaculty(f1);
		c.setFaculty(f2);
		f1.setCollege(c);
		f2.setCollege(c);
		
		session.save(f1);
		session.save(f2);
		
		
		
		
		
		
		tx.commit();
		session.close();

	}

}
