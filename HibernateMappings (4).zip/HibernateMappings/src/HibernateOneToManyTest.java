import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateOneToManyTest {
	
	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("Hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		
		System.out.println("the session is "+ session.getClass());

		Transaction tx = session.beginTransaction();
		
		Student st=new Student();
		st.setStudentName("Krish");
		
		
		Course c1=new Course();
		c1.setCourseName("Java");
		
		Course c2=new Course();
		c2.setCourseName("SQL");
		
		
		/*Course c3=new Course();
		c3.setCourseName("Python");*/
		
		
		List<Course> l=new ArrayList<>();
		l.add(c1);
		l.add(c2);
		//l.add(c3);
		
		st.setCourses(l);
		
		session.save(st);
		
		
		
/*String q="from Student";
		
		Query qry=session.createQuery(q);
		
		List empList=qry.list();
		
		Iterator it=empList.iterator();
		
		while(it.hasNext()){
			
			Student ee=(Student)it.next();
			
			System.out.println(ee.getStudentId()+"   "+ee.getStudentName());
			
			List<Course> cList =ee.getCourses();
			
			for(Course c:cList){
				
				System.out.println(c.getCourseId()+"    "+c.getCourseName());
			}
			
		}
		
		
		
		
		*/
		
		
		
		
		
		
		
		tx.commit();
		session.close();
	}
	
	
	

}
