import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateManyToManyTest {

	public static void main(String[] args) {


		Configuration cfg = new Configuration().configure("Hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		
		Station s1=new Station();
		s1.setStationName("RAL");
		
		
		Station s2=new Station();
		s2.setStationName("KCG");
		
		Train t1=new Train();
		t1.setTrainName("Repallea Fast Exp");
		
		Train t2=new Train();
		t2.setTrainName("Narayanadri Exp");
		
		List<Train> tList=new ArrayList<>();
		tList.add(t1);
		tList.add(t2);
		
		s1.setTrainList(tList);
		
		
		Train t3=new Train();
		t3.setTrainName("Delta Exp");
		
		Train t4=new Train();
		t4.setTrainName("Ventatadri Exp");
		
		List<Train> tList2=new ArrayList<>();
		tList2.add(t3);
		tList2.add(t4);
		s2.setTrainList(tList2);
		
		
		
		
		session.save(s1);
		session.save(s2);
		
		
		
		
		
		
		
		
		
		
		tx.commit();
		session.close();

	}

}
