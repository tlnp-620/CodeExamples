
public class Faculty {
	
	private int facId;
	private String facName;
	private int facSal;
	private College college;
	public int getFacId() {
		return facId;
	}
	public void setFacId(int facId) {
		this.facId = facId;
	}
	public String getFacName() {
		return facName;
	}
	public void setFacName(String facName) {
		this.facName = facName;
	}
	public int getFacSal() {
		return facSal;
	}
	public void setFacSal(int facSal) {
		this.facSal = facSal;
	}
	public College getCollege() {
		return college;
	}
	public void setCollege(College college) {
		this.college = college;
	}
	
	
	
	
	
	

}
