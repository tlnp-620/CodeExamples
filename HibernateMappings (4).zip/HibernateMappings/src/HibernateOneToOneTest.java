import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateOneToOneTest {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("Hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();
		
		System.out.println("the session is "+ session.getClass());

		Transaction tx = session.beginTransaction();

		Employee e = new Employee();
		e.setEmpName("Krish");
		e.setEmpSal(950000);

		Address a = new Address();
		a.setCity("Vijayawada");
		a.setPincode(521121);
		e.setAddress(a);
		a.setEmployee(e);

		session.save(e);
		
		
		
		
		/*String q="from Employee";
		
		Query qry=session.createQuery(q);
		
		List empList=qry.list();
		
		Iterator it=empList.iterator();
		
		while(it.hasNext()){
			
			Employee ee=(Employee)it.next();
			
			System.out.println(ee.getEmpId()+"   "+ee.getEmpName()+"   "+ee.getEmpSal());
			
			Address adr=ee.getAddress();
			
			System.out.println(adr.getAddressId()+"   "+adr.getCity()+"   "+adr.getPincode());
			
		}
		
		
		*/
		

		tx.commit();
		session.close();

	}

}
