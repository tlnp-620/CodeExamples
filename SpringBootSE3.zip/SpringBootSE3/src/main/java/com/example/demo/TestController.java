package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	
	@GetMapping("/getN")
	public String getName() {
		
		Employee e=new Employee(101,"Jhon",90000);
		
		Employee e2=new Employee();
		
		
		return "hello";
	}

}
