import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestHibernateStudent {

	public static void main(String[] args) {
		
		
		Configuration cfg=new Configuration().configure("Hibernate.cfg.xml").addAnnotatedClass(Student.class);
		SessionFactory sf=cfg.buildSessionFactory();
		Session session=sf.openSession();
		
		Transaction tx=session.beginTransaction();
		
		Student st=new Student(130, "Guru", 97);
		session.save(st);
		System.out.println("insert success...");
		tx.commit();
		session.close();
		
		
		
		

	}

}
