import java.util.List;

public class Station {
	
	private int stationId;
	private String stationName;
	private List<String> trainList;
	
	public Station(){}
	
	
	public Station(int stationId, String stationName, List<String> trainList) {
		super();
		this.stationId = stationId;
		this.stationName = stationName;
		this.trainList = trainList;
	}


	public int getStationId() {
		return stationId;
	}


	public void setStationId(int stationId) {
		this.stationId = stationId;
	}


	public String getStationName() {
		return stationName;
	}


	public void setStationName(String stationName) {
		this.stationName = stationName;
	}


	public List<String> getTrainList() {
		return trainList;
	}


	public void setTrainList(List<String> trainList) {
		this.trainList = trainList;
	}
	
	
	
	
	

}
