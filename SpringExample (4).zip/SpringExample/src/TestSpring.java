import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpring {

	public static void main(String[] args) {

	//	BeanFactory factory = new XmlBeanFactory(new ClassPathResource("SpringContext.xml")); // Bean Factory
		
		
		ApplicationContext context= new ClassPathXmlApplicationContext("SpringContext.xml"); // application Context
		
		Library lib=(Library)context.getBean("libraryBean");
		
		System.out.println(lib.getLibraryId()+"  "+lib.getLibraryName());
		
		Book b=lib.getBook();
		 
		System.out.println(b.getBookId()+"  "+b.getBookName());
		
		
		/*Station st=(Station)context.getBean("stationBean");
		
		
		System.out.println(st.getStationId()+"  "+st.getStationName());
		
		List<String> trainList=st.getTrainList();
		
		
		for(String train:trainList){
			
			System.out.println(train);
		}
		
		
		
		
       Station st2=(Station)context.getBean("stationBean2");
		
		
		System.out.println(st2.getStationId()+"  "+st2.getStationName());
		
		List<String> trainList2=st2.getTrainList();
		
		
		for(String train2:trainList2){
			
			System.out.println(train2);
		}
		
*/
		/*Employee emp = (Employee) context.getBean("empBean");
		System.out.println(emp.getEmpId()+"  "+emp.getEmpName()+"  "+emp.getEmpSal());
		
		Student st=emp.getSt();
		
		System.out.println(st.getStudentId()+" "+st.getStudentName()+" "+st.getStudentMarks());
		
		
		
		Employee emp2 = (Employee) context.getBean("empBean2");
		System.out.println(emp2.getEmpId()+"  "+emp2.getEmpName()+"  "+emp2.getEmpSal());*/
		
		
		/*Student st = (Student) context.getBean("studentBean");
		System.out.println(st.getStudentId()+"  "+st.getStudentName()+" "+st.getStudentMarks());
		
		List<String> subList= st.getSubjectList();
		for(String sub:subList){
			
			System.out.println(sub);
		}
		
		
		Faculty f=st.getFaculty();
		System.out.println(f.getFacId()+"  "+f.getFacName());
		
		*/
		
		
	}

}
