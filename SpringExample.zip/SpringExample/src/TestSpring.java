import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class TestSpring {

	public static void main(String[] args) {

		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("SpringContext.xml"));

		Employee emp = (Employee) factory.getBean("empBean");
		System.out.println(emp.getEmpId()+"  "+emp.getEmpName()+"  "+emp.getEmpSal());
		
		Employee emp2 = (Employee) factory.getBean("empBean2");
		System.out.println(emp2.getEmpId()+"  "+emp2.getEmpName()+"  "+emp2.getEmpSal());
		
		
		
		Student st = (Student) factory.getBean("studentBean");
		System.out.println(st.getStudentId()+"  "+st.getStudentName()+"  "+st.getStudentMarks());

	}

}
