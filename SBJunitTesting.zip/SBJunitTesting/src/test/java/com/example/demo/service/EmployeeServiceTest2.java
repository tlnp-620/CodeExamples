package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.demo.model.Employee;

class EmployeeServiceTest2 {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
		System.out.println("I am in @BeforeAll");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		
		System.out.println("I am in @AfterAll");
	}

	@BeforeEach
	void setUp() throws Exception {
		
		System.out.println("I am in @BeforeEach");
		
	}

	@AfterEach
	void tearDown() throws Exception {
		
		System.out.println("I am in @AfterEach");
	}

	@Test
	void testGetEmployeeName() {
		
		
		System.out.println("I am empname");
		
		EmployeeService es=new EmployeeService();
		
		Employee e=new Employee(101, "Ram", 20000);
		
		String actuvalVal= es.getEmployeeName(e);
		String expectedVal="Ram";
		//assertEquals(expectedVal, actuvalVal);
		
		assertNull(actuvalVal);
		
	}
	
	
	@Test
	void testGetEmployeeId() {
		System.out.println("I am empId");
		
		EmployeeService es=new EmployeeService();
		
		Employee e=new Employee(101, "Ram", 20000);
		
		int actuvalVal= es.getEmployeeId(e);
		int expectedVal=101;
		assertEquals(expectedVal, actuvalVal);
		
	}
	

}
