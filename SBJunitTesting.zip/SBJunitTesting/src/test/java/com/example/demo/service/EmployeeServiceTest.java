package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.example.demo.model.Employee;

class EmployeeServiceTest {
	
	
	
	
	
	
	

	@Test
	void testGetEmployeeName() {
		
		
		EmployeeService es=new EmployeeService();
		
		Employee e=new Employee(101, "Ram", 20000);
		
		String actuvalVal= es.getEmployeeName(e);
		String expectedVal="Ram";
		assertEquals(expectedVal, actuvalVal);
		
	}
	
	
	@Test
	void testGetEmployeeId() {
		
		
		EmployeeService es=new EmployeeService();
		
		Employee e=new Employee(101, "Ram", 20000);
		
		int actuvalVal= es.getEmployeeId(e);
		int expectedVal=101;
		assertEquals(expectedVal, actuvalVal);
		
	}
	
	
	@Test
	void testGetEmployeeSal() {
		
		
		EmployeeService es=new EmployeeService();
		
		Employee e=new Employee(101, "Ram", 20000);
		
		double actuvalVal= es.getEmployeeSal(e);
		double expectedVal=200000;
		assertEquals(expectedVal, actuvalVal);
		
	}


}
