package com.example.demo.service;

import com.example.demo.model.Employee;

public class EmployeeService {
	

	public String getEmployeeName(Employee e) {

		String name = null;
		
		return name;
	}
	
	
	
	public int getEmployeeId(Employee e) {

		int id = e.getEmpId();
		
		return id;
	}
	
	
	public double getEmployeeSal(Employee e) {

		double sal = e.getEmpSal();
		
		return sal;
	}

}
