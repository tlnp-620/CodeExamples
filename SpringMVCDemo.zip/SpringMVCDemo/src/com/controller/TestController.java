package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TestController {
	
	@RequestMapping("/getMsg")	
	public String getMessage(){
		
		
		return "Home";
	}
	
	
	
	
	@RequestMapping("/getLogin")	
	public String getLogin(@RequestParam("userid")String userid,@RequestParam("pwd") String pwd, Model m ){
		
		m.addAttribute("username", userid);
		m.addAttribute("password", pwd);
		
		if(userid.equals(pwd)){
			
			
			return "Success";
			
		}else{
			
			return "Fail";
			
		}
		
		
		
		
	}

}
