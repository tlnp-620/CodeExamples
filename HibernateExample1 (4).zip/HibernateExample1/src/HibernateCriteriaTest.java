import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class HibernateCriteriaTest {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("Hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();

		Transaction tx = session.beginTransaction();

		Criteria c = session.createCriteria(Employee.class);
		
	//	c.add(Restrictions.gt("empSal", new Double(60000)));
	
		
		
		List empList = c.list();
		Iterator<Employee> it = empList.iterator();

		while (it.hasNext()) {

			Employee e = (Employee) it.next();

			System.out.println(e.getEmpId() + "  " + e.getEmpName() + "  " + e.getEmpSal());

		}

		tx.commit();
		session.close();
	}

}
