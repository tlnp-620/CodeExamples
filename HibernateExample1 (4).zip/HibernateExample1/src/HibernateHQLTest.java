import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateHQLTest {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("Hibernate.cfg.xml");
		Session session = cfg.buildSessionFactory().openSession();

		/*String query = "from Employee"; // HQL quesy to fecth all records in emp table using Employee Pojo class

		Query q = session.createQuery(query); // getting Query object

		List empList = q.list(); // gtetting list of employee objects
		
		Iterator it=empList.iterator(); // ieterate employee list
		
		while(it.hasNext()){  // getting employee elements
			
			Employee e=(Employee)it.next();
			
			System.out.println(e.getEmpId()+" "+e.getEmpName()+" "+e.getEmpSal());
			
		}*/
		
		
		Transaction tx=session.beginTransaction();
		
		String query = "delete from  Employee where empId=:eid"; // HQL quesy to fecth all records in emp table using Employee Pojo class

		Query q = session.createQuery(query); // getting Query object
		
		//q.setParameter("esal", new Double(50000));
		q.setParameter("eid", 102);
		int result=q.executeUpdate();
		tx.commit();
		
		if(result>0){
		System.out.println("update success");
		}else{
			System.out.println("update fail");
		}
		
		
		session.close();
		
		
		

	}

}
