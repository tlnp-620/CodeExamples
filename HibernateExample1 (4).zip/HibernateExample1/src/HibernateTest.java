import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateTest {

	public static void main(String[] args) {
		
		
		Configuration cfg=new Configuration().configure("Hibernate.cfg.xml");
		
	      SessionFactory sf=cfg.buildSessionFactory();
	      Session session=sf.openSession();
	      
	      Employee e=new Employee();
	      e.setEmpId(103);
	     e.setEmpName("Krish");
	     e.setEmpSal(60000);
	      
	      Transaction tx=session.beginTransaction();
	      
	     // session.save(e);
	     // session.update(e);
	      //session.delete(e);
	      
	      session.saveOrUpdate(e);
	      
	     // Employee emp=(Employee)session.get(Employee.class, new Integer(101));
	   //   Employee emp=(Employee)session.load(Employee.class, new Integer(101));
	      
	      
	     // System.out.println(emp.getEmpId()+"   "+emp.getEmpName()+"  "+emp.getEmpSal());
	      
	      System.out.println("record save or update successfully...");
	      tx.commit();
	      session.close();

	}

}
