import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateNativeSQLTest {

	public static void main(String[] args) {
		
		
		Configuration cf=new Configuration().configure("Hibernate.cfg.xml");
		SessionFactory sf=cf.buildSessionFactory();
		
		Session session=sf.openSession();
		
		Transaction tx=session.beginTransaction();
		
		
		// business logic.
		
		
		//String query="update emp set emp_sal=70000 where emp_id=101";
		
		//String query="insert into emp values(109,'Math',90000)";
		
	//	String query="delete from emp where emp_id=101";
		
		String query="select * from emp";
		
		
		
	Query nq=	session.createNativeQuery(query, Employee.class); // it tkes sql query as a perameter
	
	List<Employee> empList=nq.list();
	
	
		
			
			
			
	
	
	
	Iterator<Employee> it=empList.iterator();	
	
	while(it.hasNext()){
		
		
		Employee e=(Employee)it.next();
		
		
		System.out.println(e.getEmpId() + "  "+ e.getEmpName()+ "  "+e.getEmpSal());
		
	}
		
		
		
		tx.commit();
		session.close();
		
		
		

	}

}
