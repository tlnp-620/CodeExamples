package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeRestPIService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeRestPIService es;
	
	//@RequestMapping(value="/addEmp",method = RequestMethod.POST)
	@PostMapping("/addEmp")
	public String addEmployee(@RequestBody Employee e) {
		
		
		String result=es.addEmployee(e);
		
		
		if(result.equals("success")) {
		
			return "Employee added Successfully";
		}else {
			
			return "Employee added Fail";
		}
	}
	
	
	
	
	@PutMapping("/updateEmp")
	public String updateEmployee(@RequestBody Employee e) {
		
		
		String result=es.updateEmployee(e);
		
		
		if(result.equals("success")) {
		
			return "Employee updated Successfully";
		}else {
			
			return "Employee update Fail";
		}
	}
	
	
	
	@DeleteMapping("/deleteEmp")
	public String deleteEmployee(@RequestBody Employee e) {
		
		
		String result=es.deleteEmployee(e);
		
		
		if(result.equals("success")) {
		
			return "Employee deleted Successfully";
		}else {
			
			return "Employee deleted Fail";
		}
	}
	
	
	
	@GetMapping("/getAllEmp")
	public List<Employee> getAllEmployees() {
		
		
		List<Employee> empList=es.getAllEmployees();
		
		return empList;
		
	}
	

}
