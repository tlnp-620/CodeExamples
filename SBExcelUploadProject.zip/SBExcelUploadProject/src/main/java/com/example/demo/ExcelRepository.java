package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ExcelRepository extends JpaRepository<ExcelData, Long> {
    
}
