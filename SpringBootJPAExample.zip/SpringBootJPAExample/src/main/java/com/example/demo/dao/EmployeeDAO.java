package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
@Repository
public class EmployeeDAO {
     
	
	@Autowired(required=true)	
	private EmployeeRepository empRepo;

	public void addEmployee(Employee e) {

		empRepo.save(e);

	}

	public List<Employee> getAllEmployees() {
		List<Employee> empList = new ArrayList<>();
		empRepo.findAll().forEach(empList::add);
		return empList;
	}

}
